
class CardModel{

  int? id;

  String? name;
  String? email;
  String? cardNo;
  String? expDate;
  String? cVV;
  String? image;


}