

import 'OrderDescModel.dart';

class OrderModel{


  int? id;
  String? orderId;
  String? items;
  String? type;
  List<OrderDescModel>? orderDescModelList;
}