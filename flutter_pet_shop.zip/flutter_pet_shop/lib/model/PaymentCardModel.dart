
class PaymentCardModel{

  int? id;

  String? name;
  String? desc;
  String? image;


}