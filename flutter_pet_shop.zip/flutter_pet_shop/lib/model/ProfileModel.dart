
class ProfileModel{


  String? name;
  String? email;
  String? image;

}