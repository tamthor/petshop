
class ReviewModel{

  int? id;
  String? image;
  String? name;
  String date="4th Apr,2021";
  String? desc;
  double? review;


}