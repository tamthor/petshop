class User {
  final int? id;
  final String? name;
  final String? imageUrl;

  User({this.id, this.name, this.imageUrl});

}